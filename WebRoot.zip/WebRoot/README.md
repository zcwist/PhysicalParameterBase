PhysicalParameterBase
=====================

A demo management system for physical parameter
